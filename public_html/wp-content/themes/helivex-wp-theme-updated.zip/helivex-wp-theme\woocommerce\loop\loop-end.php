<?php
/**
 * Product loop end
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/loop-end.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div>
